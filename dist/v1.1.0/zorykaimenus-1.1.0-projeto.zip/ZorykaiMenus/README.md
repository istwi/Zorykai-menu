# ZorykaiMenus1.1.0

Atualização do mod existente de menus e lojas para **Minecraft1.21.1 / Fabric / Java21**, com Impactor e instalação somente no servidor. Mod ID preservado: `zorykaimenus`.

**Downloads1.1:** [JAR](dist/v1.1.0/zorykaimenus-1.1.0.jar) · [Projeto completo](dist/v1.1.0/zorykaimenus-1.1.0-projeto.zip) · [Exemplos JSON](dist/v1.1.0/zorykaimenus-1.1.0-exemplos.zip). A entrega1.0 permanece em dist/pronto-github/.

## O que mudou

- Descontos VIP por permissões, com regras por loja/categoria/produto, teto e exclusões. Não altera preços-base nem preços de venda.
- Comprar máximo usando saldo, desconto, espaço, componentes e limites reais, seguido de confirmação.
- Condições e placeholders opcionais de equipe Cobblemon, somente de leitura.
- API pública para menus/lojas, ações, placeholders, condições, preços/descontos e eventos de comércio.
- Logs automáticos em **config/zorykaimenus/logs/erros.log**, com stack trace e rotação.

**Validação:**30 testes JUnit e105 verificações de integração aprovadas. [Relatório e limites](docs/v1.1/TESTING.md).

## Atualizar ou instalar

1. Pare o servidor e preserve uma cópia do mundo/configuração.
2. Instale somente **zorykaimenus-1.1.0.jar** na pasta mods, removendo o JAR1.0 do mesmo mod.
3. Mantenha FabricAPI0.116.6+1.21.1 e Impactor5.3.5+1.21.1, versões usadas na homologação. Java21 é necessário.
4. Inicie o servidor. discounts.json ausente será criado; configurações existentes não são sobrescritas.
5. Configure grupos no LuckPerms, valide com /zmenu validate e use /zmenu reload. Sem permissão VIP válida, o preço é integral.

O cliente não precisa de ZorykaiMenus. Para itens/modelos Cobblemon, continuam necessários os mods de conteúdo habituais. Os exemplos/diagnósticos Java são módulos de laboratório e não devem ser instalados junto ao produto em produção.

A1.1 lê JSONs1.0, inclusive arquivos diretamente em menus/shops ou subpastas. Não duplique IDs ao mover arquivos. /zmenu shop <nome> continua sendo o equivalente de /tentavip open <nome>. Nenhuma loja de blocos precisa ser criada.

## Documentação1.1

- [Análise da arquitetura1.0](docs/v1.1/ARCHITECTURE_BEFORE.md)
- [Descontos e comandos VIP](docs/v1.1/DISCOUNTS.md)
- [Comprar máximo](docs/v1.1/MAXIMUM.md)
- [Cobblemon opcional](docs/v1.1/COBBLEMON.md)
- [API e exemplos compiláveis](docs/v1.1/API.md)
- [Atualização e logs](docs/v1.1/UPGRADE.md)
- [Alterações](docs/v1.1/CHANGES.md)
- [Testes](docs/v1.1/TESTING.md)

Continuam disponíveis os comandos /zmenu, open, shop, reload, validate, migrate, status, recover e resolve. Os novos comandos administrativos são /zmenu discount reload, check <jogador> e list. Permissão: zorykaimenus.discount.admin ou operador4.

## Construir

```bash
python3 tools/prepare_dependencies.py
./gradlew clean build
```

Gradle Wrapper8.14.3 e Loom1.10.5 preservados. O preparador baixa os artefatos oficiais fixados de Impactor e Text Placeholder API com conferência de hash. Esta última é opcional no runtime das integrações externas e dependência de compilação do adaptador existente.

Saída: build/libs/zorykaimenus-1.1.0.jar. O build também compila o addon Java de exemplo; remapExampleJar produz seu JAR separado. As integrações registradas usam o namespace do addon, sem sobrescrever recursos nativos.

## Configuração e migração preservadas

[Formato JSON](docs/CONFIGURATION.md), [migração Skies](docs/MIGRATION.md), [recuperação financeira](docs/TRANSACTIONS.md) e [compatibilidade1.0](docs/COMPATIBILITY.md) continuam documentados. As diferenças atuais estão nos documentos1.1 acima.

A migração conserva510 produtos e preços dos arquivos fornecidos. Ícones ausentes podem usar o fallback explícito de papel sem mudar o ID original; ações dependentes de outros mods ainda precisam de seus serviços. Para cash/tokens/dex externos, mantenha Core/Dex e Text Placeholder API2.4.2+1.21. A integração Cobblemon não é um interpretador Molang geral.

Não apague internal/pending.sqlite para desbloquear operações incertas. Consulte os logs e a recuperação administrativa. Eventos não substituem a conciliação e não prometem entrega exatamente uma vez entre quedas.
